import itsXenon
import inspect
import os
import psutil
import shutil
import datetime
import platform
from weather import Weather,celsius
from plugins.weatherHandling import xenonWeather

def newPath(path,fileName):
    path = os.path.join(path,fileName)
    return path

def printCentre(s):
    its = s.split("\n")
    for i in its:
        "".join(i)
        return i.center(shutil.get_terminal_size().columns)


pathX = newPath("C:/Users",str(os.getlogin()))
itsXenonPath = inspect.getfile(itsXenon)
itsXenonPath = os.path.join(pathX,itsXenonPath)
xenonPath = itsXenonPath.replace("itsXenon.py","")
dataBasePath = os.path.join(xenonPath,"xenonData")
ssPath = os.path.join(dataBasePath,"Screen-Shots")

class Personal():
    def name(passw):
        from xenonData import myInfo
        name = myInfo.name
        return name

    def title(passw):
        from xenonData import myInfo
        title = myInfo.title
        return title

    def speech(passw):
        from xenonData import myInfo
        speech = myInfo.speech
        return speech

    def city(passw):
        from xenonData import myInfo
        city = myInfo.city
        return city

timeNow = f"{datetime.datetime.now().hour}:{datetime.datetime.now().minute}"

class Messages():
    def startMsg(passw):
        msg = f"""
->Welcome {Personal.name(passw)}
->Program Name: {DevInfo.assistantName(passw)}
->Manager version: {DevInfo.version(passw)}
->Current time: {timeNow}
->System Battery: {DevInfo.getBattery(passw)}
->System: {DevInfo.deskSystem(passw)}
->Charging status: {DevInfo.isChargning(passw)}
->Processor: {DevInfo.processor(passw)}
->Python version: {DevInfo.pyVer(passw)}
->System bit: {DevInfo.sysBit(passw)}
->Weather: {DevInfo.weather(passw)}

Do 'help' to see command list
"""
        return msg

    def startMsgNW(passw):
        msg = f"""
->Welcome {Personal.name(passw)}
->Program Name: {DevInfo.assistantName(passw)}
->Manager version: {DevInfo.version(passw)}
->Current time: {timeNow}
->System Battery: {DevInfo.getBattery(passw)}
->System: {DevInfo.deskSystem(passw)}
->Charging status: {DevInfo.isChargning(passw)}
->Processor: {DevInfo.processor(passw)}
->Python version: {DevInfo.pyVer(passw)}
->System bit: {DevInfo.sysBit(passw)}
->Weather : Cant load , Check your internet connection

Do 'help' to see command list
"""
        return msg

    def weatherMsg(city):
        msg = f"""
{printCentre("[WEATHER-REP0RT]")}
City: {xenonWeather.getCity(city)}
Temperature: {xenonWeather.getTemp(city)}
Pressure: {xenonWeather.getPressure(city)}
Humidity: {xenonWeather.getHumidity(city)} 
Description: {xenonWeather.getDescription(city)}

"""
        return msg

class DevInfo():
    def version(passw):
        ver = f"v[0.1]"
        return ver

    def assistantName(passw):
        name = "Xenon"
        return name
    def getBattery(passw):
        battery = psutil.sensors_battery().percent
        if psutil.sensors_battery().power_plugged:
            batteryP = f"↑ {battery}%"
        else:
            batteryP = f"{battery}%"
        return batteryP

    def isChargning(passw):
        isCharging = psutil.sensors_battery().power_plugged
        if isCharging == False:
            status = "Unpluged"
        else:
            status = "Pluged"
        return status

    def sysBit(passw):
        bit = platform.machine()
        bitS = bit.split("_")
        return str(bitS[0])

    def processor(passw):
        return str(platform.processor())

    def pyVer(passw):
        return str(platform.python_version())

    def deskSystem(passw):
        return str(platform.uname().system)

    def weather(passw):
        weather = Weather(temperature_unit=celsius)
        info = weather.fetch_weather(Personal.city(passw=True))
        #{'City: ': 'airoli', 'Temperature: ': '30°C', 'Pressure: ': 1007, 'Humidity: ': 51, 'Description: ': 'smoke'}
        strToGive = f"\n==>City: {info['City: ']}\n==>Temprature: {info['Temperature: ']}\n==>Description: {info['Description: ']}"
        return strToGive

def varSet():
    name = input("Enter your name: ")
    title = input("Enter your windows title: ")
    speech = input("Enter speech [on/off]: ")
    city = input("Enter your city: ")
    file = open(newPath(dataBasePath,"myInfo.py"),"w")
    file.write(f"name = '{name}'\ntitle = '{title}'\nspeech = '{speech}'\ncity = '{city}'")
    plugsPath = newPath(xenonPath,"plugins")
    file = open(newPath(plugsPath,"myInfo.py"),"w")
    file.write(f"name = '{name}'\ntitle = '{title}'\nspeech = '{speech}'\ncity = '{city}'")
    file.close()
    print("[PLEASE RESTART]")
    quit()