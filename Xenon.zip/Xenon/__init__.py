import funcs
import vars_setup