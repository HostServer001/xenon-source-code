import os
import vars_setup
import pyautogui as gui
from . import myInfo

def restart(realtimeVars):
    realtimeVars["running"] = False
    os.system(f"start cmd /K python {vars_setup.xenonPath}")
    wins = gui.getWindowsWithTitle(myInfo.title)
    wins[0].close()
