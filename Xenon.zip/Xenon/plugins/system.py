import vars_setup
import os

def his():
    os.system(f"start {vars_setup.newPath(vars_setup.dataBasePath,'history.txt')}")
def errRep():
    os.system(f"start {vars_setup.newPath(vars_setup.dataBasePath,'error-report.txt')}")
