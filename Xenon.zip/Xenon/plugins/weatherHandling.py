from weather import Weather,celsius
import vars_setup
import funcs

weather = Weather(temperature_unit=celsius)


class xenonWeather():
    def getTemp(city):
        report = weather.fetch_weather(city)
        temp = report["Temperature: "]
        return temp

    def getCity(city):
        return city

    def getPressure(city):
        report = weather.fetch_weather(city)
        pressure = report["Pressure: "]
        return pressure

    def getHumidity(city):
        report = weather.fetch_weather(city)
        humidity = report["Humidity: "]
        return humidity

    def getDescription(city):
        report = weather.fetch_weather(city)
        description = report["Description: "]
        return description

def weatherHandler(user):
    userS = user.split(" ")
    if len(userS) == 1:
        funcs.printAndSay(vars_setup.Messages.weatherMsg(vars_setup.Personal.city(True)))
    subCommand = userS[1]
    if len(userS) == 2:
        if subCommand == "-temp":
            funcs.printAndSay(f"Temperature [{vars_setup.Personal.city(True)}] -  {xenonWeather.getTemp(vars_setup.Personal.city(True))}")
        if subCommand == "-pressure":
            funcs.printAndSay(f"Pressure [{vars_setup.Personal.city(True)}] - {xenonWeather.getPressure(vars_setup.Personal.city(True))}")
        if subCommand == "-humidity":
            funcs.printAndSay(f"Humidity [{vars_setup.Personal.city(True)}] - {xenonWeather.getHumidity(vars_setup.Personal.city(True))}")
        if subCommand == "-description":
            funcs.printAndSay(f"Short word to describe weather over there [{vars_setup.Personal.city(True)}] - {xenonWeather.getDescription(vars_setup.Personal.city(True))}")
        else:
            city = user[8:]
            funcs.printAndSay(vars_setup.Messages.weatherMsg(city))
    else:
        subCommand = userS[1]
        city = user[(9+len(subCommand)):]
        if subCommand == "-temp":
            funcs.printAndSay(f"Temperature [{city}] -  {xenonWeather.getTemp(city)}")
        if subCommand == "-pressure":
            funcs.printAndSay(f"Pressure [{city}] - {xenonWeather.getPressure(city)}")
        if subCommand == "-humidity":
            funcs.printAndSay(f"Humidity [{city}] - {xenonWeather.getHumidity(city)}")
        if subCommand == "-description":
            funcs.printAndSay(f"Short word to describe weather over there [{city}] - {xenonWeather.getDescription(city)}")