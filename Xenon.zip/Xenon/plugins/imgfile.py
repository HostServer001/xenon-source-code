from PIL import Image, ImageDraw, ImageFont
import vars_setup
import funcs

def quicklogo(user):
    userS = user.split(" ")
    if len(userS) == 2:
        inputStr = user[5:]
        img = Image.new('RGB', (500, 500), color = 'white')
        draw = ImageDraw.Draw(img)
        font = ImageFont.truetype(vars_setup.newPath(vars_setup.dataBasePath,"FreeMonoBold.ttf"), 50)
        textS = inputStr.split(" ")
        if len(textS) > 10:
            funcs.printAndSay("Word limit reached [10]")
            raise TypeError("Word limit reached")
        text = "\n".join(textS)
        textwidth, textheight = draw.textsize(text, font)
        x = (500 - textwidth) / 2
        y = (500 - textheight) / 2
        draw.text((x, y), text, font=font, fill=(50, 50, 50))
        img.save(vars_setup.newPath(vars_setup.dataBasePath,"latest-logo.png"))
        img.show()
    else:
        try:
            userBgSplit = user.split("bgcolor")
            bgSplit2 = userBgSplit[1].split("=")
            bgSplit3 = bgSplit2[1].split(" ")
            bgColor = bgSplit3[0]
            if bgColor == "":
                funcs.printAndSay("Dont add space between '=' and variables")
                raise TypeError("Spaces used between variable and '='")
        except:
            bgColor = "black"

        try:
            userColorSplit = user.split("txt-color")
            bgSplit2 = userColorSplit[1].split("=")
            bgSplit3 = bgSplit2[1].split(" ")
            txtColor = bgSplit3[0]
            if txtColor == "":
                funcs.printAndSay("Dont add space between '=' and variables")
                raise TypeError("Spaces used between variable and '='")
        except:
            txtColor = "white"

        try:
            textS = user.split("=")
            text = textS[-1]
            if text == txtColor:
                funcs.printAndSay("Please enter text")
                raise TypeError("Text Not Given")
            if str(text).startswith("logo"):
                text = text.replace("logo","")
        except:
            text = "No Text Given"

        img = Image.new('RGB', (500, 500), color=bgColor)
        draw = ImageDraw.Draw(img)
        font = ImageFont.truetype(vars_setup.newPath(vars_setup.dataBasePath, "FreeMonoBold.ttf"), 50)
        textS = text.split(" ")
        if len(textS) > 10:
            funcs.printAndSay("Word limit reached [10]")
            raise TypeError("Word limit reached")
        text = "\n".join(textS)
        textwidth, textheight = draw.textsize(text, font)
        x = (500 - textwidth) / 2
        y = (500 - textheight) / 2
        draw.text((x, y), text, font=font, fill=txtColor)
        img.save(vars_setup.newPath(vars_setup.dataBasePath, "latest-logo.png"))
        img.show()