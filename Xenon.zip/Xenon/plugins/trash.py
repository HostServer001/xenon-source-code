import vars_setup
import os
import pyautogui as gui
import funcs

def startMsg():
    os.system("cls")
    print(vars_setup.Messages.startMsg(True))

def desk():
    funcs.printAndSay("Redirecting to Desktop")
    gui.hotkey("win","d")