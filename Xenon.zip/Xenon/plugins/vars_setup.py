import echo
import inspect
import shutil
import os
import psutil
import datetime
import platform
from weather import Weather,celsius
from weatherHandling import xenonWeather

def newPath(path,fileName):
    path = os.path.join(path,fileName)
    return path

def printCentre(s):
    its = s.split("\n")
    for i in its:
        "".join(i)
        print(i.center(shutil.get_terminal_size().columns))


pathX = os.path.join("C:/Users",os.getlogin())
itsXenonPath = inspect.getfile(echo)
xenonPath = itsXenonPath.replace("plugins/echo.py","")
xenonPath = os.path.join(pathX,xenonPath)
dataBasePath = os.path.join(xenonPath,"xenonData")
ssPath = os.path.join(dataBasePath,"Screen-Shots")

class Personal():
    def name(passw):
        import myInfo
        name = myInfo.name
        return name

    def title(passw):
        from xenonData import myInfo
        title = myInfo.title
        return title

    def speech(passw):
        from xenonData import myInfo
        speech = myInfo.speech
        return speech

    def city(passw):
        from xenonData import myInfo
        city = myInfo.city
        return city

timeNow = f"{datetime.datetime.now().hour}:{datetime.datetime.now().minute}"

class Messages():
    def startMsg(passw):
        msg = f"""
->Welcome {Personal.name(passw)}!
->Assistant Name: {DevInfo.assistantName(passw)}
->Manager version: {DevInfo.version(passw)}
->Current time: {timeNow}
->System Battery: {DevInfo.getBattery(passw)}
->System: {DevInfo.deskSystem(passw)}
->Charging status: {DevInfo.isChargning(passw)}
->Processor: {DevInfo.processor(passw)}
->Python version: {DevInfo.pyVer(passw)}
->System bit: {DevInfo.sysBit(passw)}

Do 'help' to see command list
"""
        return msg

    def weatherMsg(city):
        msg = f"""
{printCentre("[WEATHER-REP0RT]")}
City: {xenonWeather.getCity(city)}
Temperature: {xenonWeather.getTemp(city)}
Pressure: {xenonWeather.getPressure(city)}
Humidity: {xenonWeather.getHumidity(city)} 
Description: {xenonWeather.getDescription(city)}

"""
        return msg
class DevInfo():
    def version(passw):
        ver = f"v[0.1]"
        return ver

    def assistantName(passw):
        name = "Xenon"
        return name
    def getBattery(passw):
        battery = psutil.sensors_battery().percent
        if psutil.sensors_battery().power_plugged:
            batteryP = f"↑ {battery}%"
        else:
            batteryP = f"{battery}%"
        return batteryP

    def isChargning(passw):
        isCharging = psutil.sensors_battery().power_plugged
        if isCharging == False:
            status = "Unpluged"
        else:
            status = "Pluged"
        return status

    def sysBit(passw):
        bit = platform.machine()
        bitS = bit.split("_")
        return str(bitS[0])

    def processor(passw):
        return str(platform.processor())

    def pyVer(passw):
        return str(platform.python_version())

    def deskSystem(passw):
        return str(platform.uname().system)

    def weather(passw):
        weather = Weather(temperature_unit=celsius)
        info = weather.fetch_weather(Personal.city(passw=True))
        #{'City: ': 'airoli', 'Temperature: ': '30°C', 'Pressure: ': 1007, 'Humidity: ': 51, 'Description: ': 'smoke'}
        strToGive = f"\n==>City: {info['City: ']}\n==>Temprature: {info['Temperature: ']}\n==>Description: {info['Description: ']}"
        return strToGive