import vars_setup
import itsXenon

try:
    file = open(vars_setup.newPath(vars_setup.dataBasePath,"firstRun.txt"),"r")
    file.close()
    itsXenon.qLoop()
except Exception as e:
    file = open(vars_setup.newPath(vars_setup.dataBasePath,"firstRun.txt"),"w")
    file.write("This file provides the proof that xenon has been already deployed in this system")
    vars_setup.varSet()
    print("[PLAESE RESTART]")
    quit()